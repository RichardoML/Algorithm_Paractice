#include <iostream>
#include <stdio.h>
#include <map>
#include <queue>
#include <string.h>
#include <algorithm>
#include <vector>
using namespace std;

#define INF  0x3f3f3f3f
#define maxn  20001007
struct edge
{
    int u , v , d;
    edge(int a = 0 , int b = 0 , int c = 0)
    {
        u = a , v = b , d = c;
    }
}e[maxn];
int head[maxn] , next[maxn] , cnt , n;
int dis[maxn] , vis[maxn] , vt[maxn] , index;
map<int , int> mp;
struct interval
{
    int l , r , value;
    interval(int a = 0 , int b = 0 , int c = 0)
    {
        l = a , r = b , value = c;
    }
};
vector<interval> Interval;

void add(int u , int v , int d)
{
    e[cnt] = edge(u , v , d);
    next[cnt] = head[u];
    head[u] = cnt;
    cnt++;
}

void initial()
{
    Interval.clear();
    for(int i = 0; i < maxn; i++)
    {
        head[i] = -1;
        dis[i] = INF;
        vis[i] = 0;
        vt[i] = 0;
    }
    cnt = 0;
    index = 0;
    mp.clear();
}

void readcase()
{
    int a , b , c;
    for(int i = 0; i < n; i++){
        scanf("%d%d%d" , &a , &b , &c);
        b++;
        Interval.push_back(interval(a , b , c));
        mp[a] = 0;
        mp[b] = 0;
    }
    map<int , int>::iterator it;
    for(it = mp.begin(); it != mp.end(); it++){
        it -> second = index++;
    }
    it = mp.begin();
    for(int i = 0; i < index-1; i++){
        int tem = it->first;
        it++;
        add(i+1 , i , 0);
        add(i , i+1 , it->first - tem);
    }
}

bool SPFA(int start){
    queue<int> q;
    q.push(start);
    vt[start]++;
    while(!q.empty()){
        int u = q.front();
        vis[u] = 0;
        if(vt[u]>index) return false;
        q.pop();
        int Next = head[u];
        while(Next != -1){
            int v = e[Next].v , d = e[Next].d;
            if(dis[v] > dis[u]+d){
                dis[v] = dis[u]+d;
                if(vis[v] == 0){
                    vis[v] = 1;
                    vt[v]++;
                    q.push(v);
                }
            }
            Next = next[Next];
        }
    }
    return true;
}

void computing(){
    for(int i = 0; i < Interval.size(); i++){
        add(mp[Interval[i].r] , mp[Interval[i].l] , -1*Interval[i].value);
    }
    dis[index-1] = 0;
    SPFA(index-1);
    printf("%d\n" , -1*dis[0]);
}

int main()
{
    while(scanf("%d" , &n) != EOF)
    {
        initial();
        readcase();
        computing();
    }
    return 0;
}