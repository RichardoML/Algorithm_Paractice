#include <iostream>  
#include <string>  
#include <stdio.h>
#include <algorithm>  
using namespace std;  
int solve(string str1,string str2);  

int main()  
{  
    int ans;  
    string sec1, sec2;  
    cin >> sec1 >> sec2;  
    ans = min(solve(sec1, sec2), solve(sec2, sec1));  
    cout << ans << endl;  
      
    system("pause");  
}

int solve(string str1, string str2)  
{  
    int i, j, length1, length2;  
    bool flag;  
    length1 = str1.length();  
    length2 = str2.length();  
    for (i = 0; i < length1; i++)
    {  
        flag = 1;  
        for (j = i; j < length1 && j < i + length2; j++)
        {  
            if (str1[j] == '2' && str2[j - i] == '2')
            {  
                flag = 0; 
				break; 
            }  
        }  
        if (flag)
        {  
            return max(length1, i + length2);  
        }  
    }  
    return length1 + length2;  
}  
  