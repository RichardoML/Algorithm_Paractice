#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#define lowbit(x) ((x)&(-(x)))
using namespace std;
struct binaryindextree 
{
    int* A;
    int* C;//下标i从0开始
    int size;

    binaryindextree(int n);
    ~binaryindextree();
    int getsum(int x);
    void modify(int x,int val);
};
binaryindextree:: binaryindextree(int n):size(n)
{
    A = new int[n];
    C = new int[n];
    for(int i=0;i<n;i++)
    {
        C[i] = 0;
        A[i] = 0;
    }
}
binaryindextree:: ~binaryindextree()
{
    delete [] A;
    delete [] C;
}
int binaryindextree:: getsum(int x)//x表示前 x个 也就是最后一个的下标加一 如哦国x=2 ，则表示求a0 + a1的值
{
    int sum = 0;
    while( x > 0)
    {
        sum += C[x-1];
        x -= lowbit(x);
    }
    return sum; 
}
void binaryindextree:: modify(int x,int val)//modify（2.x）表示吧 a1 + x
{
    A[x-1] += val;
    while(x <= size)
    {
        C[x-1] += val;
        x += lowbit(x);
    }
}
struct treeop// 存储输入的所有操作
{
    char* operation;
    int* fork;
    int num;

    treeop(int n):num(n)
    {
        operation = new char[n];
        fork = new int[n];
    }
    ~treeop()
    {
        delete [] operation;
        delete [] fork;
    }
};
struct adjancent //一个点的邻接
{
    int dot;
    struct adjancent* next;

    adjancent(int num):dot(num)
    {
        next = NULL;
    }
};

int dfs(struct adjancent** adtable, int root,int rootstartnum, int* renumstart,int* renumend);

int main(void)
{
    //FILE*  f = fopen("Appletree3.txt","r");
    int size;//num of fork

    //fscanf(f,"%d",&size);
    scanf("%d",size);
    binaryindextree tree(size);// num of tree

    struct adjancent* adtable[size];//每个点的邻接表  adtable[i] 表示节点i+1的邻接表
    int i;
    for(i=0;i<size;i++)
    {
        adtable[i] = NULL;
    }
    int node1,node2;
    for(i=0;i<size-1;i++)
    {
        //fscanf(f,"%d",&node1);
        //fscanf(f,"%d",&node2);
        scanf("%d",&node1);
        scanf("%d",&node2);
        adjancent* n2 = new adjancent(max(node1,node2));
        n2->next = adtable[min(node1,node2)-1];
        adtable[min(node1,node2)-1] = n2;
    }//read the brunch and construct the graph/adjancent
    int opnum;
   //fscanf(f,"%d",&opnum);
    scanf("%d",&opnum);
	//fscanf(f,"%c",&enter); 
    treeop op(opnum);
    for(i=0;i<opnum;i++)
    {
        scanf("%c",&op.operation[i]);
        while(op.operation[i] != 'Q' && op.operation[i] != 'C')
        {
        	scanf("%c",&op.operation[i]);
		}
        scanf("%d",&op.fork[i]);
        //scanf("%c",&enter);
    }
    //dfs construct timestamp, obtain renum
    int renumstart[size],renumend[size];//重新编号，也就是时间戳
    dfs(adtable,1,1,renumstart,renumend);
    
    for(i=0;i<size;i++)
    {
        tree.modify(renumstart[i],1);
    }
    //run all operations step by step
    for(i=0;i<opnum;i++)
    {
        if(op.operation[i] == 'Q')
        {
           int result = tree.getsum(renumend[op.fork[i] -1]) - tree.getsum(renumstart[op.fork[i]-1]-1);
           printf("%d\n",result);
        }
        else
        {
            if(op.operation[i] == 'C')//要记录ai，没有的话不知道这个地方怎么操作
            {
                if(tree.A[renumstart[op.fork[i] -1] -1] == 0)
                {
                    tree.modify(renumstart[op.fork[i]-1],1);	
                }
                else
                {
                    if(tree.A[renumstart[op.fork[i]-1] -1] == 1)
                    {
                    	tree.modify(renumstart[op.fork[i]-1],-1);
					}
                }
            }
        }
    }


    return 0;
}

int dfs(struct adjancent** adtable, int root,int rootstartnum,int* renumstart,int* renumend)
{
    renumstart[root -1] = rootstartnum;
    //先给root一个标号,再递归的给子树进行标号

    if(adtable[root-1] == NULL)//如果是叶子节点
    {
        renumend[root-1] = rootstartnum;
        return rootstartnum;
    }
    else
    {
        struct adjancent* pointer;
        pointer = adtable[root-1];
        int maxnum = rootstartnum ;
        while(pointer != NULL)
        {
            maxnum ++;
            maxnum = dfs(adtable,pointer->dot,maxnum,renumstart,renumend);
            pointer = pointer->next;
        }
        renumend[root-1] = maxnum;
        return maxnum;
    }
}
