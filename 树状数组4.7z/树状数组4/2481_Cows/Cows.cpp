#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
using namespace std;
#define lowbit(x) ((x)&(-(x)))
int n,c[100100],ans[100100];
struct Cow  {
               int s,e,ind;
            }cow[100100];

bool cmp(struct Cow a,struct Cow b)
{
    return (a.e > b.e)||(a.e==b.e && a.s<b.s);
}

inline void add(int x)
{
    while(x<=n)
    {
        c[x]++;
        x+=lowbit(x); 
    }
}
inline int sum(int x)
{
    int sum =0 ;
    while(x>0)
    {
        sum+=c[x];
        x-=lowbit(x);

    }
    return sum;
}
int main()
{
    while(scanf("%d",&n)&&n){
       int i ;
       for(i=0;i<sizeof(c);i++)
       {    
           c[i] = 0;
       }
        for( i=1;i<=n;i++){
            scanf("%d%d",&cow[i].s,&cow[i].e);
            cow[i].s++;
            cow[i].e++;
            cow[i].ind=i;
        }
        sort(cow+1,cow+1+n,cmp);
        for(int i=1;i<=n;i++){
            if(cow[i].s==cow[i-1].s&&cow[i].e==cow[i-1].e)ans[cow[i].ind]=ans[cow[i-1].ind];
            else ans[cow[i].ind]=sum(cow[i].s);
            add(cow[i].s);
        }
        printf("%d",ans[1]);
        for(int i=2;i<=n;i++)printf(" %d",ans[i]);
        puts("");
    }
    return 0;
}