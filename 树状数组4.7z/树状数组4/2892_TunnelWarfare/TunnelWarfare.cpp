#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <string.h>
#define maxn 55555
using namespace std;
int n,m;
int c[maxn];
#define lowbit(x) ((x)&(-(x)))

int sum(int x)
{
    int sum=0;
    while(x>0)
    {
        sum+=c[x];
        x-=lowbit(x);
    }
    return sum;
}

void add(int x,int d)
{
    while(x<=n)
    {
        c[x]+=d;
        x+=lowbit(x);
    }
}

int top;
int stack[maxn];
int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        int i;
        for(i=0;i<maxn;i++)
        {
            c[i] = 0;
        }
        for(i=1;i<=n;i++)
        {
            add(i,1);
        }
        char str[5];
 
        //while(m--)
        for(;m>0;m--)
        {
            scanf("%s",str);
            if(str[0]=='D')
            {
                int pos;
                scanf("%d",&pos);
                add(pos,-1);
                stack[top] = pos;
                top++;
            }
            else if(str[0]=='R')
            {
                top--;
                int pos = stack[top];
                add(pos,1);
            }
            else
            {
                int cur,left,right,answer,rs,re;
                scanf("%d",&cur);
                if(sum(cur)-sum(cur-1)==0)
                {
                    printf("0\n");
                    continue;
                }
                left=cur;right=n;
                while(left<=right)
                {
                    int mid=(left+right)>>1;
                    if(sum(mid)-sum(cur-1)==mid-cur+1)
                    {
                        answer=mid;
                        left=mid+1;
                    }
                    else right=mid-1;
                }
                re=answer;
 
                left=1;right=cur;
                while(left<=right)
                {
                    int mid=(left+right)>>1;
                    if(sum(cur)-sum(mid-1)==cur-mid+1)
                    {
                        answer=mid;
                        right=mid-1;
                    }
                    else left=mid+1;
                }
                rs=answer;
                printf("%d\n",re-rs+1);
            }
        }
    }
    return 0;
}