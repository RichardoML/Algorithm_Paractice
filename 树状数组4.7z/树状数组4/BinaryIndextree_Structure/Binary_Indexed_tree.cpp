#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std;
#define lowbit(x) ((x)&(-(x)))
struct binaryindextree  
{
    int* A;
    int* C;
    int size;

    binaryindextree(int n);
    ~binaryindextree();
    int getsum(int x);
    void modify(int index,int val);    
}; 

binaryindextree:: binaryindextree(int n):size(n) 
{
    A = new int[n];
    C = new int[n];
    for(int i=0;i<size;i++)
    {
        C[i] = 0;
        A[i] = 0;
    }
}
binaryindextree:: ~binaryindextree()
{
    delete [] A;
    delete [] C;
}
int binaryindextree:: getsum(int x)
{
    int sum =0 ;
    while(x>0)
    {
        sum += C[x-1];
        x -= lowbit(x);
    }
    return sum;
}
void binaryindextree:: modify(int index,int val)//A[index] + val; A beign with 1
{
    while(index <= size)
    {
        C[index-1] += val;
        index += lowbit(index);
    }
    return;
}

int main(void)
{   //感觉A是不需要的
    int size;
    int num,i;
    FILE* f = fopen("binaryindextree.txt","r");
    fscanf(f,"%d",&size);
    binaryindextree ary(size);
    for(i=0;i<size;i++)
    {
        fscanf(f,"%d",&num);
        ary.modify(i+1,num);
    }
    for(i=0;i<size;i++)
    {
        printf("%d\t",ary.C[i]);
    }
    printf("\n");
    for(i=0;i<size;i++)
    {
        fscanf(f,"%d",&num);
        printf("%d\t",ary.getsum(num));
    }

    return 0;
}
