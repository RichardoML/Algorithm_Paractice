#include<iostream>
#include<stdio.h>
#include<string.h>
#include<cmath>
#include<algorithm>
#include<vector>
#include<sstream>
#define lowbit(i) ((i)&(-(i)))
using namespace std;
#define maxn 100010

struct cow
{
    long long v, x;
}a[maxn];

bool sortv(struct cow a,struct cow b)
{
    return (a.v < b.v)||(a.v == b.v && (a.x<b.x));
}

int tree[maxn], id_num[maxn];

void add(int x, int d, int tree[])
{
    while(x <= maxn)//上限是maxn
    {
        tree[x] += d;
        x += lowbit(x);
    }
}

long long sum(int x, int tree[])
{
    long long sum = 0;
    while(x)
    {
        sum += tree[x];
        x -= lowbit(x);
    }
    return sum;
}

int main()
{
    int n;
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
    {
        scanf("%lld%lld", &a[i].v, &a[i].x);
    }
    sort(a, a + n,sortv);
    long long num, tot, ans = 0;
    for(long long  i = 0; i < n; i++)
    { 
        tot = sum(a[i].x, tree);
        num = sum(a[i].x, id_num);
        ans += (num * a[i].x - tot) * a[i].v;
        num = i - num;
        tot = sum(20000, tree) - tot;
        ans += (tot - num * a[i].x) * a[i].v;
        add(a[i].x, 1, id_num); 
        add(a[i].x, a[i].x, tree);
       
    }
    cout<<ans<<endl;
    return 0;
 }