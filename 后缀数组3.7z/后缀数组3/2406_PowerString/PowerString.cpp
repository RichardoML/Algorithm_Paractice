#include<stdio.h>
#include<string.h>
#define N 1000000
char charater[N];
int next[N];
int length;
void getnext()
{
    int j=-1;
	int i=0;
	
	next[0]=-1;
	for(;i<length;)
	{
		if(j==-1||charater[i]==charater[j])
		{
            j++;
			i++;
			next[i]=j;
		}
		else
			j=next[j];
	}
}
int main()
{
	while(scanf("%s",charater)&&charater[0]!='.')
	{	
		length=strlen(charater);
		getnext();
		if(length%(length-next[length])==0)
			printf("%d\n",length/(length-next[length]));
		else
			printf("1\n");
	}
	return 0;
}