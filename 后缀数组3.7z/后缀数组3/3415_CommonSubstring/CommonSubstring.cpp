#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

#define MAXN 1100000

using namespace std;

int sa[MAXN],rank[MAXN],height[MAXN];
int wa[MAXN],wb[MAXN],wv[MAXN],cnt[MAXN];
char a[MAXN],b[MAXN];
int s[MAXN],n,m,stack[MAXN],top=0;
int mark[MAXN]; //mark[i]=1表示stack[i]是属于A串的，mark[i]=2表示stack[i]属于B串

bool cmp(int *r,int a,int b,int c)
{
    return (r[a]==r[b])&&(r[a+c]==r[b+c]);
}

void SA(int *r,int n,int m)
{
    int i,j,p;
    int *x=wa,*y=wb;
    for(i=0;i<m;i++) cnt[i]=0;
    for(i=0;i<n;i++) cnt[(x[i]=r[i])]++;
    for(i=1;i<m;i++) cnt[i]+=cnt[i-1];
    for(i=n-1;i>=0;i--) sa[--cnt[x[i]]]=i;
    for(j=1,p=1;p<n;j<<=1,m=p)
    {
        for(p=0,i=n-j;i<n;i++) y[p++]=i;
        for(i=0;i<n;i++) 
        {
            if(sa[i]>=j) y[p++]=sa[i]-j;
        }
        for(i=0;i<n;i++) wv[i]=x[y[i]];
        for(i=0;i<m;i++) cnt[i]=0;
        for(i=0;i<n;i++) cnt[wv[i]]++;
        for(i=1;i<m;i++) cnt[i]+=cnt[i-1];
        for(i=n-1;i>=0;i--) sa[--cnt[wv[i]]]=y[i];
        swap(x,y);
        for(i=1,p=1,x[sa[0]]=0;i<n;i++)
           {
                x[sa[i]]=cmp(y,sa[i-1],sa[i],j)?p-1:p++;
           } 
    }
}

void cal(int *r,int n)
{
    int i,j,k=0;
    for(i=1;i<=n;i++) rank[sa[i]]=i;
    for(i=0;i<n;height[rank[i++]]=k)
        {
            for(k?k--:0,j=sa[rank[i]-1];r[i+k]==r[j+k];k++); //!!!!!!
        }
}

int main(void)
{
    while(scanf("%d",&m)!=EOF&&m)
    {
        n=0;
        scanf("%s%s",a,b);
        int lengtha=strlen(a),lengthb=strlen(b);
        for(int i=0;i<lengtha;i++) s[n++]=a[i];
        s[n++]='$';
        for(int i=0;i<lengthb;i++) s[n++]=b[i];
        s[n]=0;
        SA(s,n+1,300);
        cal(s,n);
        top=0;
        long long  sum=0,num[3]={0,0,0}; //num[1]=字符串
        for(int i=1;i<=n;i++)
        {
            if(height[i]<m) top=num[1]=num[2]=0; //这一段已经结束了，清空栈和记录信息的数组
            else
            {
                for(int p=top;p>0&&stack[p]>height[i]-m+1;p--)
                {
                    num[mark[p]]+=height[i]-m+1-stack[p];
                    stack[p]=height[i]-m+1;
                }
                stack[++top]=height[i]-m+1;
                if(sa[i-1]<lengtha) mark[top]=1;
                else if(sa[i-1]>lengtha) mark[top]=2;
                num[mark[top]]+=height[i]-m+1;
                if(sa[i]<lengtha) sum+=num[2];
                else if(sa[i]>lengtha) sum+=num[1];
            }
        }
        printf("%lld\n",sum);
    }
    return 0;
}