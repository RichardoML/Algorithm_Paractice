//有路径压缩
//节点从0开始编号
//并不总是用最小的数字代表整个树 Union操作时未保证最小的数字作为根节点
#include <stdio.h>
#include <stdlib.h>
#include <exception>
//#include <cmath> 
#include <iostream>
using namespace std;
struct UnionFind
                {
                    int* parent;//parent node,find operation
                    int* height;//union operation 
                    int size;

                    UnionFind(int size);
                    void Union(int p,int q);//the tree node p and node q belong union
                    void init();
                    int find(int node);
                    bool issameset(int p,int q);
                };
UnionFind:: UnionFind(int size):size(size)  {
                                                parent = new int[size];
                                                height = new int[size];
                                                init();
                                                }
void UnionFind:: init()  {
                        for(int i=0;i<size;i++)
                        {
                            parent[i] = i;
                            height[i] = 0;
                        }
                    }
 int  UnionFind::find(int node)  {
                                    if(parent[node]== node) return node;//only one node 
                                    else
                                    {
                                        int root = find(parent[node]);
                                        int pnode = node;
                                        int pnodep = parent[node];
                                        while(pnodep!= root)// path reduce 
                                        {
                                            parent[pnode] = root;
                                            pnode = pnodep;
                                            pnodep = parent[pnode];
                                        }
                                    }
                                }
void UnionFind:: Union(int p,int q) {
                                        int proot = find(p);
                                        int qroot = find(q);
                                        if(proot == qroot) return;
                                        else
                                        {
                                            if(height[proot]> height[qroot])
                                            {
                                                parent[qroot] = proot;
                                            }
                                            else
                                            {
                                                if(height[proot]<height[qroot])
                                                {
                                                    parent[proot] = qroot;
                                                }
                                                else
                                                {
                                                    parent[proot] = qroot;
                                                    height[qroot] += 1;
                                                }
                                            }
                                        }
                                    }
bool UnionFind:: issameset(int p,int q) {
                                            return find(p) == find(q);
                                        }
int main(void)
{

	int size;
	cin >> size;
    UnionFind uf =  UnionFind(size);

    uf.Union(1,2);
    uf.Union(3,4);
    uf.Union(0,9);
    uf.Union(4,7);
    uf.Union(6,5);
    uf.Union(5,8);
    uf.Union(3,9);
    uf.Union(1,8);
    int i;
    for (i=0;i<size;i++)
    {
        cout << uf.find(i);
        cout << endl;
    }

    for (i=0;i<size-1;i++)
    {
        cout << uf.issameset(i,i+1); 
    }
    cout<<endl;
    for(i=0;i<size;i++)
    {
    	cout << i;
    	cout <<"\t";
	}
	cout <<endl;
	for(i=0;i<size;i++)
	{
		cout << uf.parent[i];
		cout << "\t";
	}
    return 0;
}
