#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#define SAME  1
#define EAT  2
#define BEEATED  0
#define NONE  -1
// A->C = (A->B+B->C+2)mod 3
//A->c = (A->B - C->B +4) mod 3// Bwei root时有什么效果？？嘿嘿
//由上述两个式子可以实现 推导 不同节点的关系
using namespace std;
struct UnionFind    {
                        int* parent;
                        int* height;
                        int* relation;//the relationship with parent
                        int size;

                        UnionFind(int size);   
                        ~UnionFind();  
                        void Union(int p,int q,int re);
                        int find(int p);
                        void init();
                        int deterrela(int p,int q);
                    };
UnionFind:: UnionFind(int size):size(size)
{
    parent = new int[size];
    height = new int[size];
    relation = new int[size];
    init();
}  
UnionFind:: ~UnionFind()
{
    delete [] parent;
    delete [] height;
    delete [] relation;
}
void UnionFind:: init()
{
    for(int i=0;i<size;i++)
    {
        parent[i] = i;
        height[i] = 0;
        relation[i] = SAME;
    }
   
}
void UnionFind:: Union(int p,int q,int re)
{
    int proot = find(p);
    int qroot = find(q);//find子厚p和q都连接到了自己的root
    if(proot == qroot) return;
    else
    {
        if(height[proot] > height[qroot])
        {
            parent[qroot] = proot;
            relation[qroot] = (relation[p]-((re+relation[q]+2)%3)+1)%3;

        }
        else
        {
            if(height[proot] < height[qroot])
            {
                parent[proot] = qroot;
                relation[proot] = (((re+relation[q]+2)%3)-relation[p]+1)%3;
            }
            else
            {
                parent[proot] = qroot;
                height[qroot]++;
                relation[proot] = (((re+relation[q]+2)%3)-relation[p]+1)%3;

            }
        }
    }
}
int UnionFind:: find(int p)//find help to modefy the relation between node //find 需要实现find一次就压缩路径
{
    int pp = parent[p];
    if(parent[p] == p) return p;//root
    else 
    {
        //int root = find(parent[p]);
/*      if(parent[parent[pp]] ==parent[pp]) 
        {
            parent[p] = parent[pp];
            relation[p]=(relation[p] + relation[pp]+2)%3;  
        }
*/
        
        parent[p] = find(parent[p]); 
        relation[p] = (relation[p] + relation[pp]+2)%3;
      	return parent[p]; 


      /*  int pnode = p;
        int pnodep = parent[p];
        while(pnodep!=root)
        {
            parent[pnode] = root;
            height[pnode] = 0;
            pnode = pnodep;
            pnodep = parent[pnode];
        }
       */
    }
}
                       
int UnionFind:: deterrela(int p,int q)
{
    if(p == q) return SAME;
    if(find(q) != find(p)) return NONE;//不在同一个集合中
    else//在同一颗树中
    {
        /*if(relation[p] == relation[q]) return SAME;
        else
        {
            if((relation[p]==SAME)&&(relation[q]==EAT)) return BEEATED;
            if((relation[p]==SAME)&&(relation[q]==BEEATED)) return EAT;
            if((relation[p]==EAT)&&(relation[q]==SAME)) return EAT;
            if((relation[p]==EAT)&&(relation[q]==BEEATED)) return BEEATED;
            if((relation[p]==BEEATED)&&(relation[q]==SAME)) return BEEATED;
            if((relation[p]==BEEATED)&&(relation[q]==EAT)) return EAT;
        }
        */
       //find 之后p和q都直接和root连接了
       return (relation[p] - relation[q] + 4)%3;

    }
}
struct saying   {
                    int* rela;
                    int* an1;
                    int* an2;
                    int num;

                    saying(int n):num(n){
                                            rela = new int[n];
                                            an1 = new int[n];
                                            an2 = new int[n];
                                        }
                }; 

int main(void)
{
    int annum,snum;//animals num ;speak num
    int answer,result = 0;
    FILE* f = fopen("foodlink.txt","r");
    fscanf(f,"%d",&annum);
    fscanf(f,"%d",&snum);
    //read speak;
    saying s(snum);
    int i;
    for(i=0;i<snum;i++)
    { 
        fscanf(f,"%d",&s.rela[i]);
        fscanf(f,"%d",&s.an1[i]);
        fscanf(f,"%d",&s.an2[i]);
    }
    //
    fscanf(f,"%d",&answer);
    UnionFind an(annum);
    for(i=0;i<snum;i++)//依次考察每一个
    {
        if((s.an1[i]>annum)||(s.an2[i]>annum)) result++;//number out of range -> fake
        else
        {    
            int rel = an.deterrela(s.an1[i]-1,s.an2[i]-1);
            if(rel==NONE)//right relation need union two tree
            {
                an.Union(s.an1[i]-1,s.an2[i]-1,s.rela[i]);
            }
            else
            {
              if(s.rela[i] != rel)
              {
                  result++;
              }
            }
        }
    }
  
    printf("%d\n",result);
    
    if(answer == result) cout<< "test passed!\n";
    else 
    {
        cout << "test failed!\n";
        cout << "answer : " << answer <<"\nyour answer :"<<result;
    }
    return 0;

}
