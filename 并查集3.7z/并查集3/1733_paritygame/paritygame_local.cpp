#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
#define odd 1
#define even 0
#define none -1
struct UnionFind    {
                        int*  parent;
                        int* relation;
                        int* height;
                        int size;

                        UnionFind(int size);
                        ~UnionFind();
                        void Union(int p,int q,int evenorodd);
                        int find(int p);
                        int deterela(int p,int q);
                    };
UnionFind:: UnionFind(int size)
{
    parent = new int[size];
    relation = new int[size];
    height = new int[size];
    for(int i=0 ;i<size;i++)
    {
        parent[i] = i;
        height[i] = 0;
        relation[i] = even;
    }
}
UnionFind:: ~UnionFind()
{
    delete [] parent;
    delete [] relation;
    delete [] height;
}
void UnionFind:: Union(int p,int q,int evenorodd)
{
    int proot = find(p);
    int qroot = find(q);
    if(proot == qroot) return;
    else//not in the same tree
    {
        if(height[proot] > height[qroot])
        {
            parent[qroot] = proot;
            relation[qroot] = relation[p]^relation[q]^evenorodd;
        }
        else
        {
            if(height[proot] < height[qroot])
            {
                    parent[proot] = qroot;
                    relation[proot] = relation[p]^relation[q]^evenorodd;
            }
            else 
            {
                    parent[qroot] = proot;
                    height[proot] ++;
                    relation[qroot] = relation[p]^relation[q]^evenorodd;
            }
        }
    }
} 
int UnionFind:: find(int p)//find still do path reduce
{
    if(parent[p] == p) return p;
    else 
    {
        int pp = parent[p];
        parent[p] = find(parent[p]);
        relation[p] = relation[p] ^ relation[pp];
        return parent[p];
    }
}
int UnionFind:: deterela(int p,int q)
{
    if(p == q)return even;
    int proot = find(p);
    int qroot = find(q);
    if(proot != qroot) return none;
    else
    {
        return relation[p]^relation[q];
    }
}
struct saying   {
                    int * bit1;
                    int * bit2;
                    char(*enod)[5];//even or odd
                    int num;
                    saying(int n):num(n)    {
                                                bit1 = new int[num];
                                                bit2 = new int[num];
                                                enod = new char[num][5];
                                            }
                    ~saying()   {
                                    delete [] bit1;
                                    delete [] bit2;
                                    delete [] enod;
                                }
                };

int main(void)
{
    int len,snum;//length ,saying num
    int answer,result;
    map<int,int>mp;
    FILE* f = fopen("paritygame1.txt","r");
    fscanf(f,"%d",&len);
    fscanf(f,"%d",&snum);//s说话句数
    int allnode[2*snum];
    saying s(snum);
    int i;
    for(i=0;i<snum;i++)
    {
        fscanf(f,"%d",&s.bit1[i]);
        allnode[2*i] = s.bit1[i];
        fscanf(f,"%d",&s.bit2[i]);
        allnode[2*i+1] = s.bit2[i];
        fscanf(f,"%s",s.enod[i]);
    }
    fscanf(f,"%d",&answer);
    //离散化
    sort(allnode,allnode+2*snum);
    int allnodenum = unique(allnode,allnode+2*snum) - allnode;//得到所有涉及的点的个数并重新编号
    for(i=0;i<snum;i++)
    {
        s.bit1[i] = lower_bound(allnode,allnode+allnodenum,s.bit1[i])-allnode;        
        s.bit2[i] = lower_bound(allnode,allnode+allnodenum,s.bit2[i])-allnode;  
    }

    UnionFind uf(allnodenum+2);

    for(i=0;i<snum;i++)
    {
        int rel;
       	if(!strcmp(s.enod[i] ,"even")) rel = 0;
       	else rel = 1;
        if(uf.deterela(s.bit1[i],s.bit2[i]+1) == none)//
        {
            uf.Union(s.bit1[i],s.bit2[i]+1,rel);
        }
        else
        {
            if(uf.deterela(s.bit1[i],s.bit2[i]+1) != rel)
            {
                break;//find conflict
            }
        }
    }
    if(i == snum) result = snum;
    else result = i;


    if(result == answer ) printf("test passed\n");
    else 
    {
        printf("test failed!\n");
        printf("answer :%d\t your answer :%d",answer,result);
    }
    return 0;
}
