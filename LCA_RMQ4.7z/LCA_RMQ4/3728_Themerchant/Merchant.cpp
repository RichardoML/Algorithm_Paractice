#include <stdio.h>
#include <algorithm>
using namespace std;

#define  INF 999999999
#define N 200000+5
#define swap(a,b) {int tmp=a;a=b;b=tmp;}
//#define max(a,b) (a>b?a:b)
//#define min(a,b) (a<b?a:b)
int pri[N],sumedge,head[N];

struct Edge
{
    int v,next;
    Edge(int v=0,int next=0):v(v),next(next)
    {

    }
}edge[N<<1];

inline void ins(int u,int v)
{
    sumedge++;
    edge[sumedge]=Edge(v,head[u]);
    head[u]=sumedge;
}
  
struct Type_Node
{
    int up_down,down_up;
    int maxx,minn,dad;
}shop[N][23];

int deep[N];
void DFS(int x,int father)
{
    deep[x]=deep[father]+1; 
    shop[x][0].minn=min(pri[x],pri[father]);
    shop[x][0].maxx=max(pri[x],pri[father]);
    shop[x][0].down_up=max(0,pri[father]-pri[x]);
    shop[x][0].up_down=max(0,pri[x]-pri[father]);
    for(int i=1;shop[x][i-1].dad;i++)
    {
        shop[x][i].dad=shop[shop[x][i-1].dad][i-1].dad;
        shop[x][i].maxx=max(shop[x][i-1].maxx,shop[shop[x][i-1].dad][i-1].maxx);
        shop[x][i].minn=min(shop[x][i-1].minn,shop[shop[x][i-1].dad][i-1].minn);
        shop[x][i].down_up=max(shop[x][i-1].down_up,shop[shop[x][i-1].dad][i-1].down_up);
        shop[x][i].down_up=max(shop[x][i].down_up,shop[shop[x][i-1].dad][i-1].maxx-shop[x][i-1].minn);
        shop[x][i].up_down=max(shop[x][i-1].up_down,shop[shop[x][i-1].dad][i-1].up_down);
        shop[x][i].up_down=max(shop[x][i].up_down,shop[x][i-1].maxx-shop[shop[x][i-1].dad][i-1].minn);
    }
    for(int i=head[x];i;i=edge[i].next)
    {
        int v=edge[i].v;
        if(shop[x][0].dad!=v) shop[v][0].dad=x,DFS(v,x);
    }
}

int LCA(int x,int y)
{
    if(deep[x]>deep[y]) 
    {
        swap(x,y);
    }
    int i=20;
    while(i>=0)
    {
        if(deep[shop[y][i].dad]>=deep[x]) y=shop[y][i].dad;
        i--;
    }

      if(x==y) return x;
      i=20;
      while(i>=0)
      {
        if(shop[x][i].dad!=shop[y][i].dad) x=shop[x][i].dad,y=shop[y][i].dad;
        i--;
      }   
      return shop[x][0].dad; 
}
int Query(int x,int y)
{
    int ans=0,maxx=-INF,minn=INF,lca=LCA(x,y);
    int i=20;
    while(i>=0)
    {
         if(deep[shop[x][i].dad]>=deep[lca])
        {
            ans=max(ans,max(shop[x][i].down_up,shop[x][i].maxx-minn));
            minn=min(minn,shop[x][i].minn);
            x=shop[x][i].dad;
        }
        i--;
    }
    i=20;
    while(i>=0)
    {
        if(deep[shop[y][i].dad]>=deep[lca])
        {
            ans=max(ans,max(shop[y][i].up_down,maxx-shop[y][i].minn));
            maxx=max(maxx,shop[y][i].maxx);
            y=shop[y][i].dad;
        }
        i--;
    }    
    return max(ans,maxx-minn);
}
  
inline void read(int &x)
{
    x=0;register char ch=getchar();
    while(ch<'0'||ch>'9') ch=getchar();
    for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
}
  
int main()
{
    int n; read(n);
    for(int i=1;i<=n;i++)
    {
        read(pri[i]);
    }
     
    for(int u,v,i=1;i<n;i++)
    {
        read(u),read(v);
        ins(u,v),ins(v,u);
    }
    DFS(1,0);
    int q; read(q);
    for(int u,v;q--;)
    {
       read(u),read(v);
       if(u==v) puts("0");
       else printf("%d\n",Query(u,v));
    }
    return 0;
}