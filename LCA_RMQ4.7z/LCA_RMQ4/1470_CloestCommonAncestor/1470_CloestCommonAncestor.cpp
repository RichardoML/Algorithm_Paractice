#include<stdio.h>
#include<string.h>
#define max 1000
struct Heap
{
    int head[max];
    int next[max*max];  
    int key[max*max];
    int pos;
    Heap(){clear();}
    void clear()
    {
        memset(head,-1,sizeof(head));pos=0;
    }
    void add(int s,int e)
    {
        key[pos]=e;
        next[pos]=head[s];
        head[s]=pos;
        pos++;
    }
};
int vis[max],in[max],answer[max],f[max];
Heap heap,query;

int get(int i)
{
	if(f[i]==i)
	{
        return i;
    }
    else
    {
    	return f[i]=get(f[i]);
    }
}
void tarjan(int k)
{
	int i;
	f[k]=k;
    i = heap.head[k];
	while(i!=-1)
	{
		tarjan(heap.key[i]);
		f[heap.key[i]]=k;
        i = heap.next[i];
	}

	vis[k]=1;
    i = query.head[k];

	while(i!=-1)
	{
		if(vis[query.key[i]])
			{
                answer[get(query.key[i])]++;
            }
        i =query.next[i];
	}
}
int main()
{
	int n,i,a,nn,j,b,nq;
	while(~scanf("%d",&n))
	{
		memset(vis,0,sizeof(vis));
		memset(in,0,sizeof(in));
		memset(answer,0,sizeof(answer));
		heap.clear();
		query.clear();
		for(i=1;i<=n;i++)
		{
			scanf("%d:(%d)",&a,&nn);
			for(j=1;j<=nn;j++)
			{
				scanf("%d",&b);
				heap.add(a,b);
				in[b]++;
			}
		}
		scanf("%d",&nq);
		for(i=1;i<=nq;i++)
		{
			while(getchar()!='(');
			scanf("%d%d",&a,&b);
			query.add(a,b);
			query.add(b,a);
			while(getchar()!=')');
		}


		for(i=1;i<=n;i++)
			if(!in[i])
			{
				tarjan(i);
				break;
			}
		for(i=1;i<=n;i++)
			if(answer[i])
				printf("%d:%d\n",i,answer[i]);
	}
	return 0;
}