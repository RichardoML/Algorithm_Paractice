#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX 50100
struct hash
{
	int to,w,next;
}Hash[MAX<<2],Qes[MAX<<2];  
int n,Index1,Index2,pre1[MAX],pre2[MAX],visit[MAX],ansetor[MAX],answer[MAX],dist[MAX];

void Add_edge(int a,int b,int c)   
{
	Hash[Index1].to = b;
    Hash[Index1].w = c;
	Hash[Index1].next=pre1[a];
	pre1[a]=Index1;
    Index1 ++;
}

void Add_Qes(int a,int b,int c)   
{
	Qes[Index2].to=b;
    Qes[Index2].w=c;
	Qes[Index2].next=pre2[a];
	pre2[a]=Index2;
    Index2++;
}

int Find(int x)           
{
	int s,j;
	s=x;
	while(x!=ansetor[x])
		x=ansetor[x];
	while(s!=x)
	{
		j=ansetor[s];
		ansetor[s]=x;
		s=j;
	}
	return x;
}

void LCA(int u)     
{
    int i,v;
    visit[u]=1;
    ansetor[u]=u;
    i = pre1[u];
    while(i!=-1)
    {
        v=Hash[i].to;
        if(!visit[v])      
        {
            dist[v]=dist[u]+Hash[i].w;
            LCA(v);          
            ansetor[v]=u;    
        }
        i=Hash[i].next;
    }
    i=pre2[u];
    while(i!=-1)
    {
        v=Qes[i].to;
        if(visit[v])          
        {
            answer[Qes[i].w]=dist[u]+dist[v]-dist[ansetor[Find(v)]]*2;
        }
        i=Qes[i].next;
    }
}

int main()
{
	char ch[2];
	int m,k,i,a,b,c;
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		Index1=Index2=0;
        memset(dist,0,sizeof(dist));
		memset(pre1,-1,sizeof(pre1));
        memset(ansetor,0,sizeof(ansetor));
		memset(answer,-1,sizeof(answer));
		memset(visit,0,sizeof(visit));
        memset(pre2,-1,sizeof(pre2));
		
		for(i=0;i<m;i++)
		{
			scanf("%d%d%d%s",&a,&b,&c,ch);
			Add_edge(a,b,c);   
			Add_edge(b,a,c);   
		}
		scanf("%d",&k);
		for(i=1;i<=k;i++)
		{
			scanf("%d%d",&a,&b);
			Add_Qes(a,b,i);
			Add_Qes(b,a,i);
		}
		for(i=1;i<=n;i++)
		{
			if(!visit[i])     
				LCA(i);
		}
		for(i=1;i<=k;i++)
		{
			printf("%d\n",answer[i]);
		}
	}
	return 0;
}