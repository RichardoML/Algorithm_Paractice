#include <string.h>
#include <stdio.h>
#include <algorithm>
using namespace std;
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
const int maxn=100000+10;
const int inf=9999999999;
struct Edge
{
	int to,next;
};
struct Edge edge[maxn*2];
int head[maxn],tot;
int father[maxn];
int son[maxn];
int top[maxn];
int deep[maxn];
int pre[maxn];
int num[maxn];
int stree[maxn];
int data[maxn];
int pos,n;

void addedge(int u,int v)
{
    edge[tot].to=v;
	edge[tot].next=head[u];
	head[u]=tot;
    tot++;
}

void dfs1(int u,int fath,int dep){
	int i;
	deep[u]=dep;
	father[u]=fath;
	num[u]=1;
    i=head[u];
	while(i!=-1)
    {
		int v=edge[i].to;
		if(v!=fath)
        {
			dfs1(v,u,dep+1);
			num[u]+=num[v];
			if(son[u]==-1 || num[v]>num[son[u]])
            {
				son[u]=v;
			}
		}
        i=edge[i].next;
	}
}
//给点编号得到线段树上的对应标号
void getpos(int u,int sp){
	int i;
    stree[u]=pos;
    pos++;
	top[u]=sp;	
	pre[stree[u]]=u;
	if(son[u]==-1) 
    {
        return ;
    }	
	getpos(son[u],sp);
    i=head[u];
	while(i!=-1)
    {
		int v=edge[i].to;
		if(v!=son[u] && v!=father[u])
        {
			getpos(v,v);
		}
        i=edge[i].next;
	}
}

//树状数组or线段树or其他

/*int Max(int a,int b)
{
	if(a>b) return a;
	return b;
}
*/
struct node
{
	int l,r;
	int sum,max;
};
struct node tree[maxn*3];

void PushUp(int rt)
{
	tree[rt].sum=tree[rt<<1].sum+tree[rt<<1|1].sum;
}

void build(int l,int r,int rt)
{
	tree[rt].l=l;
	tree[rt].r=r;
	tree[rt].sum=0;
	if(l==r)
    {
		return ;
	}
    else
    {
        int m=(tree[rt].l+tree[rt].r)>>1;
	    build(lson);
	    build(rson);
	    PushUp(rt);
    }
	
}

void update(int p,int add,int rt){
	if((tree[rt].l==tree[rt].r) && (tree[rt].l==p))
    {
		tree[rt].sum=add;
		return ;
	}
    else
    {
        int m=(tree[rt].l+tree[rt].r)>>1;
	    if(p<=m) update(p,add,rt<<1);
	    else update(p,add,rt<<1|1);
	    PushUp(rt);
    }
	
}

int query_sum(int L,int R,int rt){
	if(L<=tree[rt].l && tree[rt].r<=R)
    {
		return tree[rt].sum;
	}
	int m=(tree[rt].l+tree[rt].r)>>1;
	int ret=0;
	if(L<=m) ret+=query_sum(L,R,rt<<1);
	if(R>m) ret+=query_sum(L,R,rt<<1|1);
	return ret;
}

int find_sum(int u,int v){
	int f1,f2,answer=0;
	f1=top[u];
	f2=top[v];
	while(f1!=f2)
    {
		if(deep[f1]<deep[f2])
        {
			swap(f1,f2);
			swap(u,v);
		}
		answer+=query_sum(stree[f1],stree[u],1);
		u=father[f1];
		f1=top[u];
	}
	if(u==v) return answer; 
	if(deep[u]>deep[v]) 
	{
        swap(u,v);
    }
	answer+=query_sum(stree[son[u]],stree[v],1);
	return answer;
}

int e[maxn][5];

int main()
{ 
	int t,x,y;
	int q,i,s,tmp;
    tot =0;
    memset(head,-1,sizeof head);
    pos = 0;
    memset(son,-1,sizeof son);
	scanf("%d%d%d",&n,&q,&s);
	tmp=s;
	for(i=0;i<n-1;i++)
    {
		scanf("%d %d %d",&e[i][0],&e[i][1],&e[i][2]);
		addedge(e[i][0],e[i][1]);
		addedge(e[i][1],e[i][0]);
	}
	dfs1(1,0,0);
	getpos(1,1);
	build(1,n,1);
	for(i=0;i<n-1;i++)
    {
		if(deep[e[i][0]]>deep[e[i][1]]) 
		{
            swap(e[i][0],e[i][1]);
        }
		update(stree[e[i][1]],e[i][2],1);
	}
	int op;
	//while(q--)
    for(;q>0;q--)
    {
		int a,b;
		scanf("%d",&op);
		if(op==0)
        {
			scanf("%d",&a);
			printf("%d\n",find_sum(tmp,a));
			tmp=a;
		}
		else
        {
			scanf("%d %d",&a,&b);
			update(stree[e[a-1][1]],b,1);
		}
	}

	return 0;
}