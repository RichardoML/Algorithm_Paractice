#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define MAXN 100010
int cnt[MAXN<<2];
int lazy[MAXN<<2];

void pushup(int ret)
{
    cnt[ret]=cnt[ret<<1]|cnt[ret<<1|1];
}
void pushdown(int ret)
{
    if(lazy[ret])
    {  
        
        cnt[ret<<1]=cnt[ret];
        cnt[ret<<1|1]=cnt[ret];
        lazy[ret<<1]=1;
        lazy[ret<<1|1]=1;   
        lazy[ret]=0;     
    }
}
int query(int a,int b,int l,int r,int rt)
{
    if(a<=l&&b>=r) 
    {
        return cnt[rt];
    }
    pushdown(rt);
    int t1=0,t2=0;
    int m=(r+l)>>1;
   
    if(a<=m) t1=query(a,b,lson);
    if(b>m) t2=query(a,b,rson);
    return t1|t2;
}
 
void update(int a,int b,int c,int l,int r,int rt)
{

    if(a<=l&&b>=r)
    {
        cnt[rt]=1<<(c-1);
        lazy[rt]=1;
        return;
    }
    pushdown(rt);
    int m=(l+r)>>1;
    if(a<=m) update(a,b,c,lson);
    if(b>m) update(a,b,c,rson);
    
    pushup(rt);
}

int main(void)
{

    int length,numtype,oper,a,b,c,temp,t,answer;
    char type;
    scanf("%d%d%d",&length,&numtype,&oper);
    //memset(cnt,1,sizeof(cnt));
    int i;
    for(i=0;i<MAXN<<2;i++)
    {
        cnt[i] = 1;
    }
   memset(lazy,0,sizeof(lazy));
    for(i=1;i<=oper;i++)
    {
        char type[2];
        scanf("%s",type);
     
        if(type[0]=='C')
        {
            scanf("%d%d%d",&a,&b,&c);
            if(a>b)
            {
                t=a;a=b;b=t;
            }
            update(a,b,c,1,length,1);
        }
        else
        {
            scanf("%d%d",&a,&b);
            if(a>b)
            {
                  t=a;a=b;b=t;
            }
            temp=query(a,b,1,length,1);
            for(answer=0;temp>=1;temp>>=1)
            {
        
                if(temp&1) answer++;
            }
            printf("%d\n",answer);
        }
    }
     return 0;
}