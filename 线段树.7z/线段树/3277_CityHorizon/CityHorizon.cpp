#include <iostream>
#include <cmath>
#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <queue>
#include <stack>
#include <list>
#include <algorithm>
#include <map>
#include <set>
#define Pr pair<int,int>
#define fread() freopen("in.in","r",stdin)
#define fwrite() freopen("out.out","w",stdout)
using namespace std;
#define INF 0x3f3f3f3f
#define msz 10000
#define lowbit(x) ((x)&(-(x)))
bool cmp(struct Node a,struct Node b);
int get();
const double mod = 1e9+7;
const double eps = 1e-8;
struct Node
{
	int x,y;
	bool ad;
};
Node nd[88888];
int ty[44444];
int bit[44444];
int tp;
void add(int x,int d)
{
	while(x < tp)
	{
		bit[x] += d;
		x += lowbit(x);
	}
}
int sum(int x)
{
	int sum = 0;
	while(x)
	{
		sum += bit[x];
		x -= lowbit(x);
	}
	return sum;
}


int main()
{
	int n,x1,x2,y;
	long long ans;
	while(~scanf("%d",&n))
	{
		int temp = 0;
		for(int i = 0; i < n; i++)
		{
			scanf("%d%d%d",&x1,&x2,&y);
			nd[temp].ad = 1;
            nd[temp].x = x1;
			nd[temp].y = y;
			
			ty[i+1] = y;
			temp++;
            nd[temp].ad = 0;
			nd[temp].x = x2;
			nd[temp].y = y;
			temp++;
		}
		memset(bit,0,sizeof(bit));
		sort(ty+1,ty+n+1);
		sort(nd,nd+temp,cmp);
		tp = unique(ty+1,ty+n+1)-ty;
		ans = 0;
		set <int> s;
		int x;
		for(int i = 0; i < temp; ++i)
		{
			if(i && nd[i-1].x != nd[i].x)
			{
                ans += 1LL*(nd[i].x-nd[i-1].x)*get();
            }	
			int l = 1, r = tp-1;
			while(l <= r)
			{
				int mid = (l+r)>>1;
				if(ty[mid] <= nd[i].y)
				{
					l = mid+1;
					if(ty[mid] == nd[i].y)
					{
						x = mid;
						break;
					}
				}else r = mid-1;
			}
			if(nd[i].ad)
			{
				add(x,1);
			}else add(x,-1);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
bool cmp(struct Node a,struct Node b)
{
    return a.x < b.x;
}

int get()
{
	int ans = sum(tp-1);
	if(ans == 0)
	{
        return 0;
    }
	int c;
	int left = 1, right = tp-1;
	while(left <= right)
	{
		int mid = (left+right)>>1;
		int k = sum(mid);
		if(k >= ans)
		{
			right = mid-1;
			if(k == ans) c = mid;
		}else left = mid+1;
	}
	return ty[c];
}